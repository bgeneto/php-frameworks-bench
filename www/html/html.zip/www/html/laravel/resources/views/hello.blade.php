@extends('base')

@section('title')
  {{ $title }}
@endsection

@section('body')
  {{ $body }}
@endsection

