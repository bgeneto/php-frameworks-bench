<?= $this->extend('template') ?>

<?= $this->section('title') ?>
<?= $title ?>
<?= $this->endSection() ?>

<?= $this->section('body') ?>
<?= $output ?>
<?= $this->endSection() ?>
