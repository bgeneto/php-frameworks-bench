<?php

namespace App\Controllers\Benchmarking;

use CodeIgniter\Controller;

class BenchController extends Controller
{
	public function hello(): string
	{
		return view('benchmarking/hello', ['title' => 'Hello', 'output' => 'Hello, World!!!']);
	}

	public function info(): string
	{
		return phpinfo();
	}
}

